#ifndef FILM_H
#define FILM_H
#include <string>
#include <iostream>

using namespace std;

class Film : public Video
{
private:
    unsigned int count;
    int * durees[count];

public:
    /*
     * Constructor
    */
    Film() {}
    Film(string name, string pathname, int duree, int durees[]) : Video(name, pathname, duree), durees(durees), count(count){}
    virtual void setDurees(int d[]) const { durees = d; }
    virtual void getDurees(){
        return durees, count;
    }
    virtual void affichage(ostream & s) override {s << getName() << " "<< getPathname() << " "<< getDuree() << endl;}

    /*
    * modifier(arg time)
    */

    /*
     * Desctructor
    */
    virtual ~Film(){}
}
#endif // FILM_H
