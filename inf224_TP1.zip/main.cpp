#include "base.h"
#include "photo.h"
#include "video.h"

int main() {
    /*
     * Create new base and set attributes. Print on console result
    */
    Base * b = new Base();
    b->setName("This file is cool");
    b->setPathname("cool/fichier/jqjqj");
   // b->affichage(cout);

    /*
     * Create new Photo and set attributes. Print on console result
    */
    Photo * p = new Photo();
    p->setName("disney.jpg");
    p->setPathname("/cal/homes/sorube/Desktop/disney.jpg");
    p->setLatitude(10.0);
    p->setLongitude(15.0);
    //p->affichage(cout);
    //p->openObject();

    /*
     * Create new Video and set attributes. Print on console result
    */
    Video * v = new Video();
    v->setName("sample_video.mp4");
    v->setPathname("/cal/homes/sorube/Desktop/sample_video.mp4");
    v->setDuree(5);
   //v->affichage(cout);
    //v->openObject();

    Base ** tableau = new Base * [2];
    unsigned int count = 0;
    tableau[count++] = p;
    tableau[count++] = v;
    for(unsigned int i =0; i<count; i++){
        tableau[i]->affichage(cout);
    }

    /*
     * Delete created objects
    */
    delete b;
    delete p;
    delete v;
}


/*
 * make = compile
 * make clean = detruit les *.c
 * make run = compile et execute
*/
